import { stripe } from "@/lib/stripe";
import { getPayload } from 'payload'
import config from '@/payload.config'

export async function handleInvoicePaid(invoice: any) {
    const payload = await getPayload({ config })

    const subscriptionId = invoice.parent.subscription_details.metadata.db_subscription_id

    if (!subscriptionId) {
        console.error('No subscription ID found in metadata')
        return
    }

    let subscription: any
    try {
        subscription = await payload.findByID({
            collection: 'web-subscription',
            id: subscriptionId,
            depth: 2, // Fetch related product data
        })

        if (!subscription) {
            console.error('Subscription not found')
            return
        }

        // Deduct stock for each item in the subscription
        if (subscription.items && subscription.items.length > 0) {
            for (const item of subscription.items) {
                try {
                    const productId = typeof item.product === 'object' ? item.product.id : item.product
                    const variantId = item.variantID
                    const quantity = item.quantity

                    // Fetch the product to update stock
                    const productDoc = await payload.findByID({
                        collection: 'web-products',
                        id: productId,
                    })

                    if (!productDoc) {
                        console.error(`Product ${productId} not found`)
                        continue
                    }

                    // Find the variant and update its stock
                    if (productDoc.variants && Array.isArray(productDoc.variants)) {
                        const variantIndex = productDoc.variants.findIndex((v: any) => v.id === variantId)

                        if (variantIndex !== -1) {
                            const variant = productDoc.variants[variantIndex]
                            const currentStock = variant.variantStockQuantity || 0
                            const newStock = Math.max(0, currentStock - quantity)

                            // Update the variant stock
                            productDoc.variants[variantIndex].variantStockQuantity = newStock

                            // If stock reaches 0, mark as out of stock
                            if (newStock === 0) {
                                productDoc.variants[variantIndex].variantInStock = false
                            }

                            await payload.update({
                                collection: 'web-products',
                                id: productId,
                                data: {
                                    variants: productDoc.variants,
                                },
                            })

                            console.log(`✅ Stock updated for product ${productId}, variant ${variantId}: ${currentStock} → ${newStock}`)
                        } else {
                            console.error(`Variant ${variantId} not found in product ${productId}`)
                        }
                    }
                } catch (error) {
                    console.error(`Error updating stock for item:`, error)
                }
            }
        }

        try {
            const updatedSubscription = await payload.update({
                collection: 'web-subscription',
                id: subscriptionId,
                data: {
                    subsStatus: 'active',
                },
            })
        } catch (error) {
            console.error('Error updating subscription in Invoice Paid Webhook:', error)
        }

    } catch (error) {
        console.error('Error fetching subscription in Invoice Paid Webhook:', error)
        return
    }



}